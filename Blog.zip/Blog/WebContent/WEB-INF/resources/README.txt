README

url: http://localhost:8080/Blog/comente-sobre
banco de dados: MySQL

views:
	Deixei visível as bordas da tabela de forma proposital. Pensei em utilizar algum template
de blog existente na Web, mais não cheguei a aplicar (por isso deixei as bordas da tabela).
	Existe uma clara repetição de código, que poderia resolver com a utilização de templates.

Spring MVC:
	Utilizei url's amigáveis.